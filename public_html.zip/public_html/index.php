<!DOCTYPE html>
<html lang="en">
<head>
    <?php 
    include './Login_signUp/DbConnection.php';
    ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Transfer Management System</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('https://assets3.thrillist.com/v1/image/2831917/1584x1056/crop;webp=auto;jpeg_quality=60;progressive.jpg');
    background-size: cover;
    background-position: center;
    height: 100vh;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .container {
    background-color: rgba(255, 255, 255, 0.9);
    
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    max-width: 600px;
    text-align: center;
    animation: slide-in 1s ease-out;
  }
  @keyframes slide-in {
    from {
      transform: translateY(-100px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }
  h1 {
    color: #333;
    font-size: 36px;
    margin-bottom: 20px;
  }
  p {
    color: #666;
    font-size: 18px;
    margin-bottom: 40px;
  }
  .btn-signup {
    padding: 12px 24px;
    font-size: 16px;
    border: none;
    border-radius: 4px;
    background-color: #28a745; /* Green */
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s;
    margin: 0 10px;
  }
  .btn-signup:hover {
    background-color: #218838; /* Darker green */
  }
  .btn-signin {
    padding: 12px 24px;
    font-size: 16px;
    border: none;
    border-radius: 4px;
    background-color: #007bff; /* Blue */
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s;
    margin: 0 10px;
  }
  .btn-signin:hover {
    background-color: #0056b3; /* Darker blue */
  }
</style>
</head>
<body>
<div class="container">
<?php
// $password = 'password1';
// $hashed_password = password_hash($password, PASSWORD_DEFAULT);
// echo $hashed_password;
?>
  <h1>Welcome to the Employee Transfer Management System</h1>
  

  <a href="LogIn_signUp/log_up.php"><button class="btn-signup">Sign up</button></a>
  <a href="LogIn_signUp/log_in.php"><button class="btn-signin">Sign In</button></a>
</div>
</body>
</html>
