<?php
include('smtp/PHPMailerAutoload.php');

// Establish database connection
include('DbConnection.php');
// Check connection


$otp = rand(100000, 999999);
$receiverEmail = $email; // Retrieve email from the URL parameter
$subject = "Email Verification";

// Update user_jobs_system table with the OTP
$updateQuery = "UPDATE user_jobs_ystem SET OTP = '$otp' WHERE email = '$receiverEmail'";
if ($conn->query($updateQuery) === TRUE) {
    // Load HTML email template
    $emailbody = file_get_contents('email_template.php');
    $emailbody = str_replace('{{OTP}}', $otp, $emailbody);

    echo smtp_mailer($receiverEmail, $subject, $emailbody);
} else {
    echo "Error updating record: " . $conn->error;
}

// Close the database connection


function smtp_mailer($to, $subject, $msg)
{
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->IsHTML(true);
    $mail->CharSet = 'UTF-8';
    //$mail->SMTPDebug = 2;
    $mail->Username = "dankibwika820@gmail.com"; //write sender email address
    $mail->Password = "gstyycrworlfjcos"; //write app password of sender email
    $mail->SetFrom("dankibwika820@gmail.com"); //write sender email address
    $mail->Subject = $subject;
    $mail->Body = $msg;
    $mail->AddAddress($to);
    $mail->SMTPOptions = array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => false
    ));
    if (!$mail->Send()) {
        echo $mail->ErrorInfo;
    } else {
        echo "";
    }
}
?>
