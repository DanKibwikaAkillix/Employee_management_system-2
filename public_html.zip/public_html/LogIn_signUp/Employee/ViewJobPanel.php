<!DOCTYPE html>
<html lang="en">
<head>

<?php


// Include database connection
include '../DbConnection.php';

// Check if session transfer ID is set
if (!isset($_SESSION['transfer'])) {
    // Check if transfer ID is received via GET method
    if (isset($_GET['transfer'])) {
        // Assign the transfer ID received via GET to the session variable
        $_SESSION['transfer'] = $_GET['transfer'];
    } else {
        // Redirect to the job transfer page or handle the scenario where transfer ID is not received
        header("Location: JobTransfer.php");
        exit();
    }
}

// Fetch job data from the database
$transferID = $_SESSION['transfer'];
$sql = "SELECT * FROM Job WHERE id = '$transferID'";
$result = mysqli_query($conn, $sql);
$job = mysqli_fetch_assoc($result);

if (!$job) {
    echo "No job found with the given ID.";
    exit();
}
?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Job Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        #imagePreview {
            max-width: 300px;
            height: auto;
        }
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            display: none;
            z-index: 1;
        }
        .print-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .print-header h1 {
            margin: 0;
        }
        .print-header h2 {
            margin: 5px 0;
            font-size: 1.2em;
            color: #555;
        }
        .form-container {
            margin: 0 auto;
        }
        .form-container .form-control {
            display: inline-block;
            width: 100%;
            text-align: left;
        }
        .form-container label {
            display: block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>View Job Entry</h1>
        <form id="jobForm">
            <div class="mb-3">
                <label for="jobName" class="form-label">Job Name</label>
                <input type="text" class="form-control" id="jobName" name="jobName" value="<?php echo htmlspecialchars($job['job_name']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="position" class="form-label">Position</label>
                <input type="text" class="form-control" id="position" name="position" value="<?php echo htmlspecialchars($job['position']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="startDate" class="form-label">Transfer Start Date</label>
                <input type="date" class="form-control" id="startDate" name="startDate" value="<?php echo htmlspecialchars($job['transfer_start_date']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="endDate" class="form-label">Transfer End Date</label>
                <input type="date" class="form-control" id="endDate" name="endDate" value="<?php echo htmlspecialchars($job['transfer_end_date']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="posterOrPicture" class="form-label">Poster or Picture URL or Upload</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="posterOrPicture" name="posterOrPictureURL" value="<?php echo htmlspecialchars($job['poster_or_picture']); ?>" disabled>
                </div>
            </div>
            <div class="mb-3">
                <img id="imagePreview" src="<?php echo htmlspecialchars($job['poster_or_picture']); ?>" alt="Preview">
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <input type="text" class="form-control" id="status" name="status" value="<?php echo htmlspecialchars($job['status']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="company" class="form-label">Company</label>
                <input type="text" class="form-control" id="company" name="company" value="<?php echo htmlspecialchars($job['company']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($job['location']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="adminMail" class="form-label">Admin Email</label>
                <input type="email" class="form-control" id="adminMail" name="adminMail" value="<?php echo htmlspecialchars($job['admin_mail']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="postedHour" class="form-label">Posted Hour</label>
                <input type="time" class="form-control" id="postedHour" name="postedHour" value="<?php echo htmlspecialchars($job['posted_hour']); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="otherComment" class="form-label">Other Comment</label>
                <textarea class="form-control" id="otherComment" name="otherComment" rows="3" disabled><?php echo htmlspecialchars($job['other_comment']); ?></textarea>
            </div>
            <button type="button" class="btn btn-primary" onclick="printToPDF()">Print to PDF</button>
        </form>
    </div>

    <div class="notification" id="notification"></div>

    <script>
        function printToPDF() {
            const jobForm = document.getElementById('jobForm');
            const printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Print Job Entry</title>');
            printWindow.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">');
            printWindow.document.write('<style>');
            printWindow.document.write('.print-header { text-align: center; margin-bottom: 20px; }');
            printWindow.document.write('.print-header h1 { margin: 0; }');
            printWindow.document.write('.print-header h2 { margin: 5px 0; font-size: 1.2em; color: #555; }');
            printWindow.document.write('.form-container { margin: 0 auto; width: 80%; }');
            printWindow.document.write('.form-container .form-control { width: 100%; text-align: left; }');
            printWindow.document.write('.form-container label { display: block; margin-top: 10px; }');
            printWindow.document.write('</style></head><body>');
            printWindow.document.write('<div class="print-header">');
            printWindow.document.write('<h1>Company Name</h1>');
            printWindow.document.write('<h2>Company Logo</h2>');
            printWindow.document.write('</div>');
            printWindow.document.write('<div class="form-container">');
            printWindow.document.write(jobForm.outerHTML);
            printWindow.document.write('</div>');
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }
    </script>
</body>
</html>

<?php
mysqli_close($conn);
?>
