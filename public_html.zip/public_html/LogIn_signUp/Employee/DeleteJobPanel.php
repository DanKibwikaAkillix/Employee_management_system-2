<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Job Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .btn-danger {
            margin-right: 10px;
        }
        .spinner-border {
            display: block;
            margin: 20px auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Delete Job Entry</h1>
        <?php
        

        // Include database connection
        include '../DbConnection.php';

        // Check if session transfer ID is set
        if (!isset($_SESSION['transfer'])) {
            // Check if transfer ID is received via GET method
            if (isset($_GET['transfer'])) {
                // Assign the transfer ID received via GET to the session variable
                $_SESSION['transfer'] = $_GET['transfer'];
            } else {
                // Redirect to the job transfer page or handle the scenario where transfer ID is not received
                header("Location: JobTransfer.php");
                exit();
            }
        }

        // Fetch job data from the database
        $transferID = $_SESSION['transfer'];
        $sql = "SELECT * FROM Job WHERE id = '$transferID'";
        $result = mysqli_query($conn, $sql);
        $job = mysqli_fetch_assoc($result);

        if (!$job) {
            echo "<p>No job found with the given ID.</p>";
            exit();
        }

        // Check if the delete button is clicked
        if (isset($_POST['delete'])) {
            // Perform the deletion
            $deleteSql = "DELETE FROM Job WHERE id='$transferID'";
            if (mysqli_query($conn, $deleteSql)) {
                echo "<p>Job entry deleted successfully</p>";
                exit();
            } else {
                echo "<p>Error deleting record: " . mysqli_error($conn) . "</p>";
            }
        }
        ?>
        <!-- Delete confirmation form -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <p>Are you sure you want to delete the job entry for '<?php echo $job['job_name']; ?>'?</p>
            <button type="submit" name="delete" class="btn btn-danger">Yes, Delete</button>
            <a href="javascript:history.back()" class="btn btn-secondary">No, Cancel</a>
        </form>
        <div class="spinner-border" role="status" id="loadingSpinner" style="display: none;">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <script>
        document.querySelector('form').addEventListener('submit', function () {
            document.getElementById('loadingSpinner').style.display = 'inline-block';
        });
    </script>
</body>
</html>
