<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Transfer Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f7f9fc;
            color: #333;
            padding-top: 50px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #007bff;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .form-title {
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
        }
        .sidebar {
            background-color: #44576D;
            color: #fff;
            width: 250px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar li {
            margin-bottom: 15px;
        }
        .sidebar a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s;
            display: block;
            padding: 10px;
            border-radius: 5px;
        }
        .sidebar a:hover {
            background-color: #5e738c;
            color: #fff;
        }
        .sidebar a i {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <ul>
            <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="#"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="container" style="margin-left: 250px;">
        <div class="form-title">Job Transfer Form</div>
        <form action="process_job_transfer.php" method="POST">
            <div class="mb-3">
                <label for="employeeID" class="form-label">Employee ID</label>
                <input type="number" class="form-control" id="employeeID" name="employeeID" required>
            </div>
            <div class="mb-3">
                <label for="currentDepartment" class="form-label">Current Department</label>
                <input type="text" class="form-control" id="currentDepartment" name="currentDepartment" required>
            </div>
            <div class="mb-3">
                <label for="currentJobTitle" class="form-label">Current Job Title</label>
                <input type="text" class="form-control" id="currentJobTitle" name="currentJobTitle" required>
            </div>
            <div class="mb-3">
                <label for="transferToDepartment" class="form-label">Transfer To Department</label>
                <input type="text" class="form-control" id="transferToDepartment" name="transferToDepartment" required>
            </div>
            <div class="mb-3">
                <label for="transferToJobTitle" class="form-label">Transfer To Job Title</label>
                <input type="text" class="form-control" id="transferToJobTitle" name="transferToJobTitle" required>
            </div>
            <div class="mb-3">
                <label for="transferDate" class="form-label">Transfer Date</label>
                <input type="date" class="form-control" id="transferDate" name="transferDate" required>
            </div>
            <div class="mb-3">
                <label for="reasonForTransfer" class="form-label">Reason For Transfer</label>
                <textarea class="form-control" id="reasonForTransfer" name="reasonForTransfer" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="Pending">Pending</option>
                    <option value="Approved">Approved</option>
                    <option value="Completed">Completed</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Submit</button>
        </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
