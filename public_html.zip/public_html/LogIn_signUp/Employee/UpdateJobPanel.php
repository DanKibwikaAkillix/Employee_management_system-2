<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Job Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        #imagePreview {
            max-width: 300px;
            height: auto;
        }
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            display: none;
            z-index: 1;
        }
        .form-container {
            margin: 0 auto;
        }
        .form-container .form-control {
            display: inline-block;
            width: 100%;
            text-align: left;
        }
        .form-container label {
            display: block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Job Entry</h1>
        <?php
      

        // Include database connection
        include '../DbConnection.php';

        // Check if session transfer ID is set
        if (!isset($_SESSION['transfer'])) {
            // Check if transfer ID is received via GET method
            if (isset($_GET['transfer'])) {
                // Assign the transfer ID received via GET to the session variable
                $_SESSION['transfer'] = $_GET['transfer'];
            } else {
                // Redirect to the job transfer page or handle the scenario where transfer ID is not received
                header("Location: JobTransfer.php");
                exit();
            }
        }

        // Fetch job data from the database
        $transferID = $_SESSION['transfer'];
        $sql = "SELECT * FROM Job WHERE id = '$transferID'";
        $result = mysqli_query($conn, $sql);
        $job = mysqli_fetch_assoc($result);

        if (!$job) {
            echo "<p>No job found with the given ID.</p>";
            exit();
        }

        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Validate and sanitize input data
            $jobName = htmlspecialchars($_POST['jobName']);
            $position = htmlspecialchars($_POST['position']);
            $startDate = htmlspecialchars($_POST['startDate']);
            $endDate = htmlspecialchars($_POST['endDate']);
            $status = htmlspecialchars($_POST['status']);
            $company = htmlspecialchars($_POST['company']);
            $adminMail = htmlspecialchars($_POST['adminMail']);
            $postedHour = htmlspecialchars($_POST['postedHour']);
            $otherComment = htmlspecialchars($_POST['otherComment']);
            $location = htmlspecialchars($_POST['location']);

            // Store uploaded image
            $posterOrPictureURL = '';

            if (!empty($_FILES['posterOrPictureFile']['name'])) {
                $file_name = $_FILES['posterOrPictureFile']['name'];
                $file_size = $_FILES['posterOrPictureFile']['size'];
                $file_tmp = $_FILES['posterOrPictureFile']['tmp_name'];
                $file_type = $_FILES['posterOrPictureFile']['type'];
                $tmp = explode('.', $file_name);
                $file_ext = strtolower(end($tmp));

                $extensions = array("jpeg", "jpg", "png");

                if (in_array($file_ext, $extensions) === false) {
                    echo "Extension not allowed, please choose a JPEG or PNG file.";
                    exit();
                }

                if ($file_size > 2097152) {
                    echo 'File size must be less than 2 MB';
                    exit();
                }

                $posterOrPictureURL = 'Media/' . $file_name;
                move_uploaded_file($file_tmp, $posterOrPictureURL);
            } elseif (!empty($_POST['posterOrPictureURL'])) {
                $posterOrPictureURL = htmlspecialchars($_POST['posterOrPictureURL']);
            } else {
                $posterOrPictureURL = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWRlbA9DuwMTyssCnApsZwEXAI-qSaKCetew&s';
            }

            // SQL query to update data in the database
            $sql = "UPDATE Job SET 
                        job_name='$jobName', 
                        position='$position', 
                        transfer_start_date='$startDate', 
                        transfer_end_date='$endDate', 
                        poster_or_picture='$posterOrPictureURL', 
                        status='$status', 
                        company='$company', 
                        location='$location', 
                        admin_mail='$adminMail', 
                        posted_hour='$postedHour', 
                        other_comment='$otherComment' 
                    WHERE id='$transferID'";

            if (mysqli_query($conn, $sql)) {
                echo "<p>Record updated successfully</p>";
            } else {
                echo "<p>Error: " . $sql . "<br>" . mysqli_error($conn) . "</p>";
            }
        }

        mysqli_close($conn);
        ?>

        <form class="form-container" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
            <!-- Form fields with pre-populated values from database -->
            <!-- Job Name -->
            <div class="mb-3">
                <label for="jobName" class="form-label">Job Name</label>
                <input type="text" class="form-control" id="jobName" name="jobName" value="<?php echo htmlspecialchars($job['job_name']); ?>" required>
            </div>
            <!-- Position -->
            <div class="mb-3">
                <label for="position" class="form-label">Position</label>
                <input type="text" class="form-control" id="position" name="position" value="<?php echo htmlspecialchars($job['position']); ?>">
            </div>
            <!-- Transfer Start Date -->
            <div class="mb-3">
                <label for="startDate" class="form-label">Transfer Start Date</label>
                <input type="date" class="form-control" id="startDate" name="startDate" value="<?php echo htmlspecialchars($job['transfer_start_date']); ?>">
            </div>
            <!-- Transfer End Date -->
            <div class="mb-3">
                <label for="endDate" class="form-label">Transfer End Date</label>
                <input type="date" class="form-control" id="endDate" name="endDate" value="<?php echo htmlspecialchars($job['transfer_end_date']); ?>">
            </div>
            <!-- Poster or Picture URL or Upload -->
            <div class="mb-3">
                <label for="posterOrPicture" class="form-label">Poster or Picture URL or Upload</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="posterOrPicture" name="posterOrPictureURL" placeholder="Paste image URL here" value="<?php echo htmlspecialchars($job['poster_or_picture']); ?>">
                    <input type="file" class="form-control" id="posterOrPictureFile" name="posterOrPictureFile" accept="image/*">
                </div>
            </div>
            <!-- Image Preview -->
            <div class="mb-3">
                <img id="imagePreview" src="<?php echo htmlspecialchars($job['poster_or_picture']); ?>" alt="Preview">
            </div>
            <!-- Status -->
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="On" <?php if ($job['status'] == 'On') echo 'selected'; ?>>On</option>
                    <option value="Close" <?php if ($job['status'] == 'Close') echo 'selected'; ?>>Close</option>
                </select>
            </div>
            <!-- Company -->
            <div class="mb-3">
                <label for="company" class="form-label">Company</label>
                <input type="text" class="form-control" id="company" name="company" value="<?php echo htmlspecialchars($job['company']); ?>">
            </div>
            <!-- Location -->
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($job['location']); ?>">
            </div>
            <!-- Admin Email -->
            <div class="mb-3">
                <label for="adminMail" class="form-label">Admin Email</label>
                <input type="email" class="form-control" id="adminMail" name="adminMail" value="<?php echo htmlspecialchars($job['admin_mail']); ?>" disabled>
            </div>
            <!-- Posted Hour -->
            <div class="mb-3">
                <label for="postedHour" class="form-label">Posted Hour</label>
                <input type="time" class="form-control" id="postedHour" name="postedHour" value="<?php echo htmlspecialchars($job['posted_hour']); ?>">
            </div>
            <!-- Other Comment -->
            <div class="mb-3">
                <label for="otherComment" class="form-label">Other Comment</label>
                <textarea class="form-control" id="otherComment" name="otherComment" rows="3"><?php echo htmlspecialchars($job['other_comment']); ?></textarea>
            </div>
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>

    <script>
        const posterOrPictureURLInput = document.getElementById('posterOrPicture');
        const posterOrPictureFileInput = document.getElementById('posterOrPictureFile');
        const imagePreview = document.getElementById('imagePreview');

        posterOrPictureURLInput.addEventListener('input', () => {
            const url = posterOrPictureURLInput.value;
            imagePreview.src = url;
        });

        posterOrPictureFileInput.addEventListener('change', () => {
            const file = posterOrPictureFileInput.files[0];
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });
    </script>
</body>
</html>
