<?php
    // Database connection
    require_once('../DbConnection.php');

    // SQL query to fetch job records
    $sql = "SELECT id, job_name AS companyName, position, location, transfer_start_date AS transferDate FROM Job";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Array to store job data
        $jobData = array();

        // Fetch data from the result set
        while ($row = mysqli_fetch_assoc($result)) {
            // Push each row as an associative array into the $jobData array
            $jobData[] = $row;
        }
    } else {
        $jobData = array(); // If no records found, initialize an empty array
    }

    mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Transfer Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
        }
        .table-container {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background-color: #44576D;
            color: #fff;
        }
        .search-container {
            margin-bottom: 20px;
        }
        .search-container input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .pagination-container {
            margin-top: 20px;
            overflow: hidden;
        }
        .pagination {
            margin: 0;
            padding: 0;
            list-style-type: none;
            text-align: center;
        }
        .pagination li {
            display: inline;
            margin-right: 5px;
        }
        .pagination li a {
            display: block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #f4f4f4;
            color: #333;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .pagination li a.active {
            background-color: #44576D;
            color: #fff;
        }
        .no-records {
            margin-top: 20px;
            text-align: center;
            font-style: italic;
        }
        .refresh-button {
            margin-top: 10px;
            text-align: center;
        }
        .refresh-button button {
            background-color: #44576D;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 16px;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        .refresh-button button:hover {
            background-color: #5e738c;
        }
        .refresh-button button i {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- HTML content -->
        <h1>Job Transfer Dashboard</h1>
        <div class="create-button">
            <!-- Create new job button -->
            <a href="createJobTransf.php"><button><i class="fas fa-plus"></i> Create New Job Transfer</button></a>
        </div>
        <br>
        <div class="search-container">
            <!-- Search input field -->
            <input type="text" id="searchInput" placeholder="Search...">
        </div>
        <div class="table-container">
            <!-- Job table -->
            <table id="jobTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Company Name</th>
                        <th>Position</th>
                        <th>Location</th>
                        <th>Transfer Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Table rows will be inserted here dynamically -->
                </tbody>
            </table>
            <!-- Pagination -->
            <div class="pagination-container">
                <ul class="pagination" id="pagination"></ul>
            </div>
            <!-- No records message -->
            <div class="no-records" id="noRecordsMessage" style="display: none;">No records to display</div>
            <!-- Refresh button -->
            <div class="refresh-button" id="refreshButton" style="display: none;">
                <button onclick="window.location.reload();"><i class="fas fa-sync-alt"></i> Refresh</button>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const jobData = <?php echo json_encode($jobData); ?>;
            const searchInput = document.getElementById('searchInput');
            const jobTable = document.getElementById('jobTable');
            const pagination = document.getElementById('pagination');
            const noRecordsMessage = document.getElementById('noRecordsMessage');
            const refreshButton = document.getElementById('refreshButton');

            let currentPage = 1;
            const recordsPerPage = 10;

            function renderTable(data) {
                const startIndex = (currentPage - 1) * recordsPerPage;
                const endIndex = startIndex + recordsPerPage;
                const paginatedData = data.slice(startIndex, endIndex);

                jobTable.querySelector('tbody').innerHTML = '';
                paginatedData.forEach(job => {
                    const row = `
                        <tr>
                            <td>${job.id}</td>
                            <td>${job.companyName}</td>
                            <td>${job.position}</td>
                            <td>${job.location}</td>
                            <td>${job.transferDate}</td>
                            <td>
                                <a href="viewJobTranfr.php?transfer=${job.id}"> <button onclick="viewJob(${job.id})"><i class="far fa-eye"></i> View</button></a>
                                <a href="updateJobTransf.php?transfer=${job.id}"><button onclick="updateJob(${job.id})"><i class="fas fa-edit"></i> Update</button></a>
                                <a href="DeleteJobTransf.php?transfer=${job.id}"><button onclick="deleteJob(${job.id})"><i class="fas fa-trash-alt"></i> Delete</button></a>
                            </td>
                        </tr>
                    `;

                    
                    jobTable.querySelector('tbody').innerHTML += row;
                });
            }

            function renderPagination(totalRecords) {
                pagination.innerHTML = '';
                const totalPages = Math.ceil(totalRecords / recordsPerPage);

                for (let i = 1; i <= totalPages; i++) {
                    const li = document.createElement('li');
                    const a = document.createElement('a');
                    a.textContent = i;
                    a.href = '#';
                    a.addEventListener('click', function() {
                        currentPage = i;
                        updateTable();
                    });
                    if (i === currentPage) {
                        a.classList.add('active');
                    }
                    li.appendChild(a);
                    pagination.appendChild(li);
                }
            }

            function updateTable() {
                const query = searchInput.value.trim().toLowerCase();
                const filteredData = jobData.filter(job =>
                    job.companyName.toLowerCase().includes(query) ||
                    job.position.toLowerCase().includes(query) ||
                    job.location.toLowerCase().includes(query) ||
                    job.transferDate.includes(query)
                );

                if (filteredData.length === 0) {
                    noRecordsMessage.style.display = 'block';
                    refreshButton.style.display = 'block';
                } else {
                    noRecordsMessage.style.display = 'none';
                    refreshButton.style.display = 'none';
                }

                renderTable(filteredData);
                renderPagination(filteredData.length);
            }

            searchInput.addEventListener('input', updateTable);

            // Initialize table
            updateTable();
        });

        function viewJob(id) {
            console.log('View job with ID:', id);
        }

        function updateJob(id) {
            console.log('Update job with ID:', id);
        }

        function deleteJob(id) {
            console.log('Delete job with ID:', id);
        }
    </script>
</body>
</html>
