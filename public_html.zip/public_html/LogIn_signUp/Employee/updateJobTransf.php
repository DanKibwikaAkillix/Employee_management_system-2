<?php
session_start();

// Include database connection
include '../DbConnection.php';

// Check if session email is set
if (!isset($_SESSION['email'])) {
    // Check if email is received via GET method
    if (isset($_GET['email'])) {
        // Assign the email received via GET to the session variable
        $_SESSION['email'] = $_GET['email'];
    } else {
        // Redirect to the login page or handle the scenario where email is not received
        header("Location: login.php");
        exit();
    }
}

$email = $_SESSION['email'];

$query = "SELECT * FROM signinuser WHERE email_address = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

// Check if profile picture exists, else use default
$profilePicture = !empty($user['ProfilePicture']) ? "Media/" . htmlspecialchars($user['ProfilePicture']) : "https://i.pinimg.com/564x/7f/c4/c6/7fc4c6ecc7738247aac61a60958429d4.jpg";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Transfer Portal Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .dashboard1 {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .sidebar1 {
            background-color: #44576D;
            color: #fff;
            width: 250px;
            flex-shrink: 0;
            padding: 20px;
            transition: transform 0.5s ease-in-out, width 0.5s ease-in-out, background-color 0.5s;
            position: fixed;
            top: 0;
            bottom: 0;
            overflow-y: auto;
            border-radius: 0px 10px 10px 0px;
            z-index: 1000;
        }
        .sidebar1 ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar1 li {
            margin-bottom: 15px;
        }
        .sidebar1 a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px;
        }
        .sidebar1 a:hover {
            background-color: #5e738c;
            color: #fff;
        }
        .sidebar1 a i {
            margin-right: 10px;
        }
        .main-content1 {
            flex-grow: 1;
            padding: 20px;
            margin-left: 250px;
            transition: margin-left 0.5s ease-in-out, padding 0.5s ease-in-out;
        }
        .menu-icon1 {
            display: none;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .menu-icon1.active {
            transform: rotate(90deg);
        }
        @media (max-width: 768px) {
            .dashboard1 {
                overflow-x: hidden;
            }
            .sidebar1 {
                left: -250px;
                width: 250px;
            }
            .sidebar1.active {
                left: 0;
            }
            .main-content1 {
                margin-left: 0;
                padding-top: 80px;
            }
            .menu-icon1 {
                display: block;
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 1100;
            }
        }
        .profile1 {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }
        .profile1 img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
            transition: transform 0.5s;
        }
        .profile1 img:hover {
            transform: scale(1.1);
        }
        .username1 {
            font-size: 16px;
        }

        .mainLi1 {
            background: #5e738c;
        }
    </style>
</head>
<body>
    <div class="dashboard1">
        <div class="sidebar1" id="sidebar1">
            <div class="profile1">
                <img src="<?php echo $profilePicture; ?>" alt="Profile Picture">
                <div class="username1"><?php echo htmlspecialchars($user['userName']); ?></div>
            </div>
            <ul>
                <li class="mainLi1"><a href="myportal.php?email=<?php echo $_SESSION['email'] ?>"><i class="fas fa-tasks"></i> View Applications</a></li>
                <li><a href="ProfileMy.php?email=<?php echo $_SESSION['email'] ?>"><i class="fas fa-user"></i> View Profile</a></li>
                <li><a href="JobTransfer.php"><i class="fas fa-briefcase"></i> Manage Job Transfer</a></li> <!-- Added line -->
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
                
            </ul>
        </div>
        <div class="main-content1">
            <div class="menu-icon1" onclick="toggleSidebar1()"><i class="fas fa-bars"></i></div>
            <!-- Your main content goes here -->
            <div style="padding: 5%;">

                <?php 
                include('UpdateJobPanel.php'); 
                
                ?>
                
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script>
        function toggleSidebar1() {
            var sidebar1 = document.getElementById('sidebar1');
            var menuIcon1 = document.querySelector('.menu-icon1');
            sidebar1.classList.toggle('active');
            menuIcon1.classList.toggle('active');
        }

        // Close sidebar when clicking outside of it
        window.onclick = function(event) {
            var sidebar1 = document.getElementById('sidebar1');
            var menuIcon1 = document.querySelector('.menu-icon1');
            if (!event.target.closest('.sidebar1') && !event.target.closest('.menu-icon1')) {
                sidebar1.classList.remove('active');
                menuIcon1.classList.remove('active');
            }
        };
    </script>
</body>
</html>

