<?php
session_start();
include '../DbConnection.php';

if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

$email = $_SESSION['email'];

$query = "SELECT * FROM signinuser WHERE email_address = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

$defaultProfilePicture = "https://i.pinimg.com/564x/7f/c4/c6/7fc4c6ecc7738247aac61a60958429d4.jpg";
$profilePicture = !empty($user['ProfilePicture']) ? "Media/" . htmlspecialchars($user['ProfilePicture']) : $defaultProfilePicture;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userName = $_POST['userName'];
    $firstName = $_POST['FirstName'];
    $lastName = $_POST['LastName'];
    $phoneNumber = $_POST['PhoneNumber'];
    $email = $_POST['Email'];
    $gender = $_POST['Gender'];
    $dateOfBirth = $_POST['DateOfBirth'];
    $address = $_POST['Address'];
    $jobTitle = $_POST['JobTitle'];
    $linkedIn = $_POST['LinkedIn'];
    $otherSocialMedia = $_POST['OtherSocialMedia'];

    if ($_FILES['ProfilePicture']['name']) {
        $profilePicture = $_FILES['ProfilePicture']['name'];
        $target_dir = "Media/";
        $target_file = $target_dir . basename($profilePicture);

        $check = getimagesize($_FILES['ProfilePicture']['tmp_name']);
        if ($check !== false) {
            if (move_uploaded_file($_FILES['ProfilePicture']['tmp_name'], $target_file)) {
                // File uploaded successfully
            } else {
                echo "Sorry, there was an error uploading your file.";
                exit();
            }
        } else {
            echo "File is not an image.";
            exit();
        }
    } else {
        $profilePicture = $user['ProfilePicture'];
    }

    $query = "UPDATE signinuser SET userName = ?, FirstName = ?, LastName = ?, PhoneNumber = ?, Email = ?, Gender = ?, DateOfBirth = ?, Address = ?, ProfilePicture = ?, JobTitle = ?, LinkedIn = ?, OtherSocialMedia = ? WHERE ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssssssssi", $userName, $firstName, $lastName, $phoneNumber, $email, $gender, $dateOfBirth, $address, $profilePicture, $jobTitle, $linkedIn, $otherSocialMedia, $user['ID']);

    if ($stmt->execute()) {
        echo "Profile updated successfully.";
        header('Location: ProfileMy.php');
    } else {
        echo "Error updating profile: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Transfer Portal Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            color: #333;
            font-family: 'Roboto', sans-serif;
            background: url("https://img.freepik.com/premium-vector/abstract-white-shapes-background_79603-1360.jpg?w=826");
            background-size: cover;
            background-attachment: fixed;
            margin: 0;
        }
        .dashboard {
            display: flex;
            flex-direction: row;
            min-height: 100vh;
        }
        .sidebar {
            background-color: #44576D;
            color: #fff;
            width: 250px;
            flex-shrink: 0;
            padding: 20px;
            transition: transform 0.3s ease-in-out;
            position: fixed;
            top: 0;
            bottom: 0;
            overflow-y: auto;
            border-radius: 0px 10px 10px 0px;
            z-index: 1000;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar li {
            margin-bottom: 15px;
        }
        .sidebar a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px;
        }
        .sidebar a:hover {
            background-color: #5e738c;
            color: #fff;
        }
        .sidebar a i {
            margin-right: 10px;
        }
        .main-content {
            margin-left: 270px;
            padding: 20px;
            margin-top: 20px;
            flex-grow: 1;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-container form input, .form-container form select, .form-container form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #dbdbdb;
            border-radius: 5px;
        }
        .profile1 {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }
        .profile1 img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .profile-box {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 20px;
        }
        .profile-box img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }
        .profile-box input[type="file"] {
            display: none;
        }
        .profile-box label {
            cursor: pointer;
            position: absolute;
            bottom: 10px;
            background-color: rgba(0, 0, 0, 0.7);
            color: #fff;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
        }
        .menu-icon {
            display: none;
            cursor: pointer;
            color: #fff;
            font-size: 24px;
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 1100;
        }
        @media (max-width: 768px) {
            .dashboard {
                flex-direction: column;
            }
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.open {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
            .menu-icon {
                display: block;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar" id="sidebar">
            <span class="menu-icon" onclick="toggleSidebar()">
                <i class="fas fa-bars"></i>
            </span>
            <div class="profile1">
                <img src="<?php echo $profilePicture; ?>" alt="Profile Picture">
                <div class="username"><?php echo htmlspecialchars($user['userName']); ?></div>
            </div>
            <ul>
                <li><a href="myPortal.php?email=<?php echo urlencode(base64_encode($_SESSION['email'])) ?>"><i class="fas fa-tasks"></i> View Applications</a></li>
                <li><a href="ProfileMy.php?email=<?php echo urlencode(base64_encode($_SESSION['email'])) ?>"><i class="fas fa-user"></i> View Profile</a></li>
                <li><a href="JobTransfer.php?email=<?php echo urlencode(base64_encode($_SESSION['email'])) ?>"><i class="fas fa-briefcase"></i> Manage Job Transfer</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="form-container">
                <form action="" method="POST" enctype="multipart/form-data">
                    <label for="userName">Username:</label>
                    <input type="text" name="userName" value="<?php echo htmlspecialchars($user['userName']); ?>" required>
                    
                    <label for="FirstName">First Name:</label>
                    <input type="text" name="FirstName" value="<?php echo htmlspecialchars($user['FirstName']); ?>">
                    
                    <label for="LastName">Last Name:</label>
                    <input type="text" name="LastName"value="<?php echo htmlspecialchars($user['LastName']); ?>">
                    
                    <label for="PhoneNumber">Phone Number:</label>
                    <input type="text" name="PhoneNumber" value="<?php echo htmlspecialchars($user['PhoneNumber']); ?>">
                                        
                    <label for="Email">Email:</label>
                    <input type="email" name="Email" value="<?php echo htmlspecialchars($user['Email']); ?>" required>
                                        
                    <label for="Gender">Gender:</label>
                    <select name="Gender">
                        <option value="Male" <?php if ($user['Gender'] == 'Male') echo 'selected'; ?>>Male</option>
                        <option value="Female" <?php if ($user['Gender'] == 'Female') echo 'selected'; ?>>Female</option>
                        <option value="Other" <?php if ($user['Gender'] == 'Other') echo 'selected'; ?>>Other</option>
                    </select>
                                        
                    <label for="DateOfBirth">Date of Birth:</label>
                    <input type="date" name="DateOfBirth" value="<?php echo htmlspecialchars($user['DateOfBirth']); ?>">
                                        
                    <label for="Address">Address:</label>
                    <textarea name="Address" rows="4"><?php echo htmlspecialchars($user['Address']); ?></textarea>
                                        
                    <label for="ProfilePicture">Profile Picture:</label>
                    <div class="profile-box">
                        <img src="<?php echo $profilePicture; ?>" alt="Current Profile Picture">
                        <input type="file" name="ProfilePicture" accept="image/*">
                        <label>Choose File</label>
                    </div>
                                        
                    <label for="JobTitle">Job Title:</label>
                    <input type="text" name="JobTitle" value="<?php echo htmlspecialchars($user['JobTitle']); ?>">
                                        
                    <label for="LinkedIn">LinkedIn Profile:</label>
                    <input type="text" name="LinkedIn" value="<?php echo htmlspecialchars($user['LinkedIn']); ?>">
                                        
                    <label for="OtherSocialMedia">Other Social Media:</label>
                    <input type="text" name="OtherSocialMedia" value="<?php echo htmlspecialchars($user['OtherSocialMedia']); ?>">
                                        
                    <button type="submit">Update Profile</button>
                    </form>
                    </div>
                    </div>
                    </div>
                    
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
                    <script>
                    function toggleSidebar() {
                        var sidebar = document.getElementById('sidebar');
                        sidebar.classList.toggle('open');
                    }
                    
                    // Close sidebar when clicking outside of it
                    window.addEventListener('mouseup', function(event) {
                        var sidebar = document.getElementById('sidebar');
                        if (event.target != sidebar && !sidebar.contains(event.target)) {
                            sidebar.classList.remove('open');
                        }
                    });
                    </script>
                    </body>
                    </html>
                    
