<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Job Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        #imagePreview {
            max-width: 300px;
            height: auto;
        }
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            display: none;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Job Entry</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
            <div class="mb-3">
                <label for="jobName" class="form-label">Job Name</label>
                <input type="text" class="form-control" id="jobName" name="jobName" required>
            </div>
            <div class="mb-3">
                <label for="position" class="form-label">Position</label>
                <input type="text" class="form-control" id="position" name="position">
            </div>
            <div class="mb-3">
                <label for="startDate" class="form-label">Transfer Start Date</label>
                <input type="date" class="form-control" id="startDate" name="startDate">
            </div>
            <div class="mb-3">
                <label for="endDate" class="form-label">Transfer End Date</label>
                <input type="date" class="form-control" id="endDate" name="endDate">
            </div>
            <div class="mb-3">
                <label for="posterOrPicture" class="form-label">Poster or Picture URL or Upload</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="posterOrPicture" name="posterOrPictureURL" placeholder="Paste image URL here">
                    <input type="file" class="form-control" id="posterOrPictureFile" name="posterOrPictureFile" accept="image/*">
                </div>
            </div>
            <div class="mb-3">
                <img id="imagePreview" src="" alt="Preview">
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="On" selected>On</option>
                    <option value="Close">Close</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="company" class="form-label">Company</label>
                <input type="text" class="form-control" id="company" name="company">
            </div>
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" id="location" name="location">
            </div>
            <div class="mb-3">
                <label for="adminMail" class="form-label">Admin Email</label>
                <input type="email" class="form-control" id="adminMail" name="adminMail7" value="<?php echo $_SESSION['email']; ?>" disabled>
                <!-- Hidden input field to pass admin email value to PHP script -->
                <?php 
                echo '<input type="hidden" name="adminMail" value=" '. $_SESSION['email'].' ">';
                ?>
            </div>


            <div class="mb-3">
                <label for="postedHour" class="form-label">Posted Hour</label>
                <input type="time" class="form-control" id="postedHour" name="postedHour">
            </div>
            <div class="mb-3">
                <label for="otherComment" class="form-label">Other Comment</label>
                <textarea class="form-control" id="otherComment" name="otherComment" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <div class="notification" id="notification"></div>

    <script>
        function updateImage() {
            let imageUrl = document.getElementById('posterOrPicture').value;
            if (!imageUrl) {
                imageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWRlbA9DuwMTyssCnApsZwEXAI-q            .SaKCetew&s';
            }
            document.getElementById('imagePreview').src = imageUrl;
        }

        document.getElementById('posterOrPictureFile').addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });

        document.getElementById('posterOrPicture').addEventListener('input', updateImage);

        // Initial update
        updateImage();

        // Notification message
        function showNotification(message) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.style.display = 'block';
            setTimeout(function() {
                notification.style.display = 'none';
            }, 5000); // 5 seconds
        }

        // Form validation
        function validateForm() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            if (startDate && endDate && startDate > endDate) {
                showNotification('Error: End date must be after start date.');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data
    $jobName = htmlspecialchars($_POST['jobName']);
    $position = htmlspecialchars($_POST['position']);
    $startDate = htmlspecialchars($_POST['startDate']);
    $endDate = htmlspecialchars($_POST['endDate']);
    $status = htmlspecialchars($_POST['status']);
    $company = htmlspecialchars($_POST['company']);
    $adminMail = htmlspecialchars($_POST['adminMail']);
    $postedHour = htmlspecialchars($_POST['postedHour']);
    $otherComment = htmlspecialchars($_POST['otherComment']);
    $location = htmlspecialchars($_POST['location']);

    // Store uploaded image
    $posterOrPictureURL = '';

    if (!empty($_FILES['posterOrPictureFile']['name'])) {
        $file_name = $_FILES['posterOrPictureFile']['name'];
        $file_size = $_FILES['posterOrPictureFile']['size'];
        $file_tmp = $_FILES['posterOrPictureFile']['tmp_name'];
        $file_type = $_FILES['posterOrPictureFile']['type'];
        $tmp = explode('.', $file_name);
        $file_ext = strtolower(end($tmp));
        
        $extensions = array("jpeg", "jpg", "png");

        if (in_array($file_ext, $extensions) === false) {
            echo "Extension not allowed, please choose a JPEG or PNG file.";
            exit();
        }

        if ($file_size > 2097152) {
            echo 'File size must be less than 2 MB';
            exit();
        }

        $posterOrPictureURL = 'Media/' . $file_name;
        move_uploaded_file($file_tmp, $posterOrPictureURL);
    } elseif (!empty($_POST['posterOrPictureURL'])) {
        $posterOrPictureURL = htmlspecialchars($_POST['posterOrPictureURL']);
    } else {
        $posterOrPictureURL = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWRlbA9DuwMTyssCnApsZwEXAI-qSaKCetew&s';
    }

    // Database connection
    require_once('../DbConnection.php');

    // SQL query to insert data into the database
    $sql = "INSERT INTO Job (job_name, position, transfer_start_date, transfer_end_date, poster_or_picture, status, company, location, admin_mail, posted_hour, other_comment) VALUES ('$jobName', '$position', '$startDate', '$endDate', '$posterOrPictureURL', '$status', '$company', '$location', '$adminMail', '$postedHour', '$otherComment')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

