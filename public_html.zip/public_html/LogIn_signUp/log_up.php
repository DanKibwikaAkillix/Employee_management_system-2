<?php
include 'DbConnection.php';


$username = $password = $confirm_password = $email = "";
$username_err = $password_err = $confirm_password_err = $email_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Check input errors before inserting into database
    if (empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($email_err)) {
        // Prepare a SELECT statement to check if user already exists
        $sql_check = "SELECT id FROM user_jobs_ystem WHERE email = ?";

        if ($stmt_check = $conn->prepare($sql_check)) {
            // Bind variables to the prepared statement as parameters
            $stmt_check->bind_param("s", $param_email);

            // Set parameters
            $param_email = $email;

            // Attempt to execute the prepared statement
            if ($stmt_check->execute()) {
                // Store result
                $stmt_check->store_result();

                if ($stmt_check->num_rows == 0) {
                    // User does not exist, insert new record
                    $sql_insert_user_jobs_ystem = "INSERT INTO user_jobs_ystem (email, password, status) VALUES (?, ?, ?)";

                    if ($stmt_insert_user_jobs_ystem = $conn->prepare($sql_insert_user_jobs_ystem)) {
                        // Bind variables to the prepared statement as parameters
                        $stmt_insert_user_jobs_ystem->bind_param("sss", $param_email, $param_password, $param_status);

                        // Set parameters
                        $param_email = $email;
                        $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
                        $param_status = "Employee";

                        // Attempt to execute the prepared statement
                        if ($stmt_insert_user_jobs_ystem->execute()) {
                            // Insert into SignInUser table
                            $sql_insert_signinuser = "INSERT INTO signinuser (email_address, password, userName) VALUES (?, ?, ?)";
                            
                            if ($stmt_insert_signinuser = $conn->prepare($sql_insert_signinuser)) {
                                // Bind variables to the prepared statement as parameters
                                $stmt_insert_signinuser->bind_param("sss", $param_email, $param_password, $param_username);

                                // Set parameters
                                $param_email = $email;
                                $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
                                $param_username = $username;

                                // Attempt to execute the prepared statement
                                $stmt_insert_signinuser->execute();
                            }
                            session_start();

                            // Store data in session variables
                            $_SESSION["email"] = $email;
                            
                            include ('sendOTP.php');
                            // Redirect to OTP verification page
                            header("Location:Employee/OTP.php?email=".$email);
                            exit();
                        } else {
                            echo "Something went wrong. Please try again later.";
                        }
                    }
                } else {
                    // User already exists
                    $email_err = "This email is already registered.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt_check->close();
        }
    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('https://assets3.thrillist.com/v1/image/2831917/1584x1056/crop;webp=auto;jpeg_quality=60;progressive.jpg');
    background-size: cover;
    background-position: center;
    height: 100vh;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .container {
    background-color: rgba(255, 255, 255, 0.9);
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    max-width: 600px;
    text-align: center;
    animation: slide-in 1s ease-out;
  }
  @keyframes fade-in {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  .error-message {
    color: #ff0000;
    margin-top: 10px;
    animation: fade-in 1s ease-out, fade-out 1s ease-in <?php echo ($timeout_duration - 1); ?>s forwards;
  }
  @keyframes fade-out {
    from { opacity: 1; }
    to { opacity: 0; }
  }
  h1 {
    color: #333;
  }
  input {
    padding: 10px;
    margin: 5px;
    border-radius: 4px;
    border: 1px solid #ccc;
    width: 250px;
    box-sizing: border-box;
  }
  button {
    padding: 10px 20px;
    margin: 10px;
    border-radius: 4px;
    border: none;
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
  }
  button:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>
<div class="container">
  <h1>Create Account</h1>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <input type="text" name="username" placeholder="Username" value="<?php echo $username; ?>" required><br>
    <input type="password" name="password" placeholder="Password" value="<?php echo $password; ?>" required><br>
    <input type="password" name="confirm_password" placeholder="Confirm Password" value="<?php echo $confirm_password; ?>" required><br>
    <input type="email" name="email" placeholder="Email Address" value="<?php echo $email; ?>" required><br>
    <button type="submit">Create Account</button>
    <div class="error-message"><?php echo $username_err . $password_err . $confirm_password_err . $email_err; ?></div>
  </form>
</div>
</body>
</html>
