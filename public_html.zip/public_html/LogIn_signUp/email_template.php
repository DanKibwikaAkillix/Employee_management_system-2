
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
    <!-- Add any necessary CSS styles here -->
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>Email Verification</h1>
    <p>Your 6 Digit OTP Code: <strong>{{OTP}}</strong></p>
    <!-- Add images and animations here -->
    <img src="https://cdn.dribbble.com/users/498505/screenshots/2639699/verification_shot.jpg?resize=768x576&vertical=center" alt="Image">
    <div class="animation">
        <img src=https://img.freepik.com/vetores-premium/colecao-de-assinatura-de-e-mail-em-cores-gradientes_23-2147814606.jpg?w=740">
    </div>
</body>
</html>