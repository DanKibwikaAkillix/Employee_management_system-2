<?php
session_start();

// Include database connection
include '../DbConnection.php';

// Define variables and initialize with empty values
$otp = "";
$otp_err = "";
$attempt_limit = 5;
$timeout_duration = 30; // in seconds

// Initialize attempt count if not set
$_SESSION["attempts"] = $_SESSION["attempts"] ?? $attempt_limit;

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate OTP
    if (empty(trim($_POST["otp"]))) {
        $otp_err = "Please enter the OTP.";
    } else {
        $otp = trim($_POST["otp"]);
    }

    // Check if there are no input errors
    if (empty($otp_err)) {
        // Prepare a SELECT statement
        $sql = "SELECT otp FROM user_jobs_ystem WHERE email = ?";

        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_email);

            // Set parameters
            $param_email = $_SESSION["email"];

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Store result
                $stmt->store_result();

                // Check if OTP exists and matches
                if ($stmt->num_rows == 1) {
                    // Bind result variables
                    $stmt->bind_result($db_otp);
                    if ($stmt->fetch()) {
                        if ($otp == $db_otp) {
                            // OTP is correct, redirect to dashboard
                            header("Location: AdminMyDashboard.php");
                            exit();
                        } else {
                            // Incorrect OTP, decrement attempt count
                            $_SESSION["attempts"]--;

                            // If attempts are exhausted, redirect to index page
                            if ($_SESSION["attempts"] <= 0) {
                                header("Location: ../../index.php");
                                exit();
                            }

                            $otp_err = "Incorrect OTP. Please try again.";
                        }
                    }
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>OTP Verification</title>

<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('https://assets3.thrillist.com/v1/image/2831917/1584x1056/crop;webp=auto;jpeg_quality=60;progressive.jpg');
    background-size: cover;
    background-position: center;
    height: 100vh;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .container {
    background-color: rgba(255, 255, 255, 0.9);
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    max-width: 600px;
    text-align: center;
    animation: slide-in 1s ease-out;
  }
  @keyframes slide-in {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }
  h1 {
    color: #333;
    margin-bottom: 20px;
  }
  p {
    color: #555;
    margin-bottom: 20px;
  }
  input {
    padding: 15px;
    margin: 15px 0;
    width: calc(100% - 30px);
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 18px;
    transition: all 0.3s;
  }
  input:focus {
    border-color: #007bff;
    outline: none;
  }
  button {
    padding: 15px 30px;
    font-size: 18px;
    border: none;
    border-radius: 6px;
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s;
    width: 100%;
  }
  button:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>
<div class="container">
  <h1>OTP Verification</h1>
  <p>An OTP has been sent to your registered email. Please enter the OTP below:</p>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <input type="text" name="otp" placeholder="Enter OTP" required><br>
    <span style="color: red;"><?php echo $otp_err; ?></span><br>
    <button type="submit">Verify OTP</button>
  </form>
</div>
</body>
</html>
