<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Job Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Create Job Entry</h1>
        <form action="submit_job.php" method="POST">
            <div class="mb-3">
                <label for="jobName" class="form-label">Job Name</label>
                <input type="text" class="form-control" id="jobName" name="jobName" required>
            </div>
            <div class="mb-3">
                <label for="position" class="form-label">Position</label>
                <input type="text" class="form-control" id="position" name="position">
            </div>
            <div class="mb-3">
                <label for="startDate" class="form-label">Transfer Start Date</label>
                <input type="date" class="form-control" id="startDate" name="startDate">
            </div>
            <div class="mb-3">
                <label for="endDate" class="form-label">Transfer End Date</label>
                <input type="date" class="form-control" id="endDate" name="endDate">
            </div>
            <div class="mb-3">
                <label for="posterOrPicture" class="form-label">Poster or Picture URL</label>
                <input type="text" class="form-control" id="posterOrPicture" name="posterOrPicture">
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="On" selected>On</option>
                    <option value="Close">Close</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="company" class="form-label">Company</label>
                <input type="text" class="form-control" id="company" name="company">
            </div>
            <div class="mb-3">
                <label for="adminMail" class="form-label">Admin Email</label>
                <input type="email" class="form-control" id="adminMail" name="adminMail">
            </div>
            <div class="mb-3">
                <label for="postedHour" class="form-label">Posted Hour</label>
                <input type="number" class="form-control" id="postedHour" name="postedHour">
            </div>
            <div class="mb-3">
                <label for="postedMinute" class="form-label">Posted Minute</label>
                <input type="number" class="form-control" id="postedMinute" name="postedMinute">
            </div>
            <div class="mb-3">
                <label for="otherComment" class="form-label">Other Comment</label>
                <input type="text" class="form-control" id="otherComment" name="otherComment">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
